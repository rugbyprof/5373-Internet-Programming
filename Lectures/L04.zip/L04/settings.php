<?php
$settings = ['username'=>'wine_site',
	     'password' => 'GJhr1yejGuj4e4gw',
	     'dbname' => 'wine_site'
];
