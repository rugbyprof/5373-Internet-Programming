<?php
// Turn error reporting on during testing (not production)
error_reporting(1);

require('settings.php');
require('class_upload.php');


$db = new mysqli("localhost", $settings['username'], $settings['password'], $settings['dbname']);
// If we have an error connecting to the db, then exit page
if ($db->connect_errno) {
    print_response(['success'=>false,"error"=>"Connect failed: ".$db->connect_error]);
}

if(array_key_exists('route',$_GET)){
    $route = $_GET['route'];
}elseif(array_key_exists('route',$_POST)){
    $route = $_POST['route'];
}

$routes = ['routes'=>
    [
        ['type'=>'post','name'=>'register','params'=>[]],
        ['type'=>'post','name'=>'login','params'=>['email','']],
        ['type'=>'post','name'=>'fileUpload','params'=>[]],   
    ]
];

$response = false;

switch($route){
    case 'fileUpload':
         $response = doUpload($settings,$_FILES,'./uploads');
         break;
    default:
        $urls = [];
        foreach($routes['routes'] as $route){
            $urls[] = ['type'=>$route['type'],'url'=>'https://wtfhw.us'.$_SERVER['PHP_SELF']."?route=".$route['name']];
        }
        $response = $urls;
}

if($response !== false){
    $response['success']=true;
    logg($response);
    print_response($response);
}
////////////////////////////////////////////////////////////////////////

function doUpload($settings,$files,$path){
    $uploader = new Upload($settings,$files,$path);
    return $uploader->doUploads();
}


function print_response($response){
    if($response['data']){
        $response['data_size'] = sizeof($response['data']);
    }
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}


