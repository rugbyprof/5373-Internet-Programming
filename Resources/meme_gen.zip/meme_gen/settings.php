<?php
$settings = ['username'=>'memes',
	     'password' => 'oyuRFsYCfCfJAeoV',
	     'dbname' => 'memes'
];
